{-# LANGUAGE NoMonomorphismRestriction, ScopedTypeVariables, TypeOperators,
  TypeFamilies, FlexibleContexts, TupleSections, Rank2Types #-}


module Data.Storage where

import Prelude hiding (sequence)
import Data.Record.Label
import Util.Prelude
import Snowfall.Binary
import Control.Monad.State (StateT(..), evalStateT)

import qualified Data.Traversable as Trav
import qualified Data.Sequence as Seq
import qualified Data.Sequence.Extra as Seq
import Data.Sequence (Seq)

type Handled s = (s, Handle s)

class C s where
  type Handle s :: *
  run :: (Handled s -> IO a) -> s -> IO a

with = flip run

applyRun :: (C s) => (t -> s) -> ((t, Handle s) -> IO a) -> t -> IO a
applyRun applyF runF x = do
  h <- getHandle $ applyF x
  runF (x, h)

-- Same logic for every traversable functor
instance (C s) => C (Seq s) where
  type Handle (Seq s) = Seq (Handle s)
  run f xs = do
    hs <- Trav.mapM getHandle xs
    f (xs, hs)

getHandle :: C s => s -> IO (Handle s)
getHandle = run $ return . snd

type M' h = StateT h IO
type F' s h a = s -> M' h a

-- Monad type
type M s = M' (Handle s)

-- Kleisli arrow for monad type
type F s a = F' s (Handle s) a

type Update s = F s s

runEvalStateT :: C s => (s -> M s a) -> s -> IO a
runEvalStateT f = run $ \(s, h) -> evalStateT (f s) h

evalEvalStateT :: C s => (s -> M s (a, h)) -> s -> IO a
evalEvalStateT f = liftM fst . runEvalStateT f

-- withLens :: (h :-> h') -> M' h' a -> M' h a
-- withLens lens m = StateT $ \h -> do
--   (x, hl') <- runStateT m (getL lens h)
--   return (x, setL lens hl' h)

withLens :: 
   (forall a. f a :-> g a) ->
   (g s -> M' (g h) (a, g s)) -> (f s -> M' (f h) (a, f s))
withLens lens f x = StateT $ \h -> do  
  let i = getL lens h
  ((a, y'), i') <- runStateT (f y) i
  return ((a, setL lens y' x), setL lens i' h)
  where
  y = getL lens x

-- Analog of Data.Traversable.sequence which transforms state monad type
-- (from single handle being carried to Seq of them)

sequence :: Seq (M' h a) -> M' (Seq h) (Seq a)
sequence ms = StateT $ Seq.unzip <.> Trav.sequence . Seq.zipWith runStateT ms

mapM :: (C s) => F s a -> F (Seq s) (Seq a)
mapM f = sequence . fmap f

updateAt :: (C s) => Int -> Update s -> Update (Seq s)
updateAt i f = \xs -> StateT $ \hs -> do
  (x', h') <- runStateT (f $ Seq.index xs i) (Seq.index hs i) 
  return (Seq.update i x' xs, Seq.update i h' hs)

add :: C s => (forall a. a -> Seq a -> Seq a) -> s -> Update (Seq s)
add cons x xs = StateT $ \hs -> with x $
  \(x, h) -> return (cons x xs, cons h hs)

snoc = add $ flip (Seq.|>)

remove :: C s => Int -> Update (Seq s)
remove i xs = StateT $ \hs -> return (Seq.remove i xs, Seq.remove i hs)
