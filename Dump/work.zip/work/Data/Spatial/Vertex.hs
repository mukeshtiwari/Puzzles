{-# LANGUAGE MultiParamTypeClasses, FlexibleInstances, 
  NoMonomorphismRestriction #-}

module Data.Spatial.Vertex where

import Prelude hiding ((<=), min, max, (+), (-), map, abs, zipWith)
import qualified Prelude as P
import Control.Applicative
import Data.Tensor
import Data.Monoid
import Data.Foldable (Foldable, fold)
import qualified Data.Foldable as Fold

class (Functor v, Foldable v, Applicative v, RealFloat a, Ord (v a)) => C v a

min = liftA2 P.min
max = liftA2 P.max

instance (RealFloat a) => C Vertex2 a
instance (RealFloat a) => C Vertex3 a

-- norm ::  (C v, Floating c) => v -> c
-- norm = sqrt . getSum . fold (Sum . realToFrac) . fmap (\x -> x * x)

-- distance ::  (C v, Floating c) => v -> v -> c
-- distance x y = norm $ x - y

-- data Cons t v = Cons !t !v deriving (Show, Eq, Ord)

-- instance (RealFloat t, C v) => C (Cons t v) where
--   pure x = x `Cons` pure x
--   map f (Cons t v) = f t `Cons` map f v
--   liftA2 f (Cons t1 v1) (Cons t2 v2) = f t1 t2 `Cons` liftA2 f v1 v2
--   foldZip f (Cons t1 v1) (Cons t2 v2) = f t1 t2 `mappend` foldZip f v1 v2

-- instance (RealFloat a) => C (Vertex2 a) where
--   pure x = A.pure x
--   map f = fmap f
--   liftA2 f = A.liftA2 f
--   foldZip f v1 v2 = F.fold $ A.liftA2 f v1 v2

-- instance (RealFloat a) => C (Vertex3 a) where
--   pure x = A.pure x
--   map f = fmap f
--   liftA2 f = A.liftA2 f
--   foldZip f v1 v2 = F.fold $ A.liftA2 f v1 v2
