{-# LANGUAGE ScopedTypeVariables, TemplateHaskell, TypeFamilies,
  NoMonomorphismRestriction, TypeSynonymInstances #-}


module Data.Spatial.Index.Sim where
--testing purpose
import Test.QuickCheck 
import Control.Applicative
import Data.List
--testing

import Data.IntMap (IntMap)
import qualified Data.IntMap as IntMap
import System.Random
import qualified Data.Bits as B
import Data.Int
import Control.Monad
--import Snowfall.Binary

--import qualified Data.Storage as Stor

import Text.Printf
import System.Environment
--import Util.ClockTime

--import Processor.ShapeTypes
--import Processor.EventId

--import Util.ClockTime
import Control.DeepSeq
import Data.DeriveTH (derive, makeNFData, makeBinary)

--import Util.Prelude

{--

import qualified Data.Spatial.Shape as Shape
import qualified Data.Spatial.BoundingBox as Box
import qualified Data.Spatial.Index as Index

--}

sizeIncrement = 100
maxLocation = 100000
maxSizePower = 6


data Index = Index {indexSize::Float, indexIds::[Int], indexDown::(IntMap.IntMap Index)}
  | IndexLeaf {indexSize::Float, indexIds::[Int]}
  | IndexEmpty {indexSize::Float}
  deriving ( Show , Eq ) 

--generate data for QuickCheck testing for Index Type
instance Arbitrary a => Arbitrary ( IntMap a )  where 
	arbitrary = liftM IntMap.fromList  arbitrary 



-- commented by Mukesh . Seems like its generating an infinity list for some test cases. Not sure looking into the matter
instance Arbitrary Index where 
	arbitrary = 
	  oneof [ liftM3 Index arbitrary arbitrary arbitrary , liftM2 IndexLeaf arbitrary arbitrary , liftM IndexEmpty arbitrary ] 


{--Its generating the data set fine but could be imporved more .
instance  Arbitrary Index where 
	arbitrary = sized arbIndex 

arbIndex 0 = liftM IndexEmpty arbitrary
arbIndex 1 = liftM2 IndexLeaf arbitrary arbitrary
arbIndex n = frequency [ ( 2 , liftM IndexEmpty arbitrary ) , ( 2 ,  liftM2 IndexLeaf arbitrary arbitrary ) , ( 1 , arbIndex $ div n 2   ) ] 
--}





{-- commented by Mukesh 
derive makeNFData ''Index
derive makeBinary ''Index
--}

{-- Commented by Mukesh 
type NoIdShape = (EventId, DrawShape)
type T = (Index, IntMap NoIdShape)

instance Stor.C T where
  type Stor.Handle T = ()
  run f self = f (self, ())

type instance Index.Shape T = IdShape
instance Index.C T where
  intersect = intersect
  insertMany = insertMany

new = (IndexEmpty 10e9, IntMap.empty)

intersect box self@(index, shapesMap) = return (shapes, self)
  where
  shapes = getShapes shapesMap ids 
  ids = queryBox index $ fromBox box

insertMany shapes self = return $ foldl insert self shapes
  where
  insert (index, map) (id, eid, s) = (
    insertShape id (fromBox $ Shape.boundingBox s) index,
    IntMap.insert id (eid, s) map
    )

getShapes map = fmap $ \id -> tag id (map IntMap.! id)

tag id (eid, ds) = (id, eid, ds)

fromBox (Box.Con (Vertex2 x1 y1) (Vertex2 x2 y2)) = ((x1, y1), (x2, y2))

--}

--Ok. Passed all the 100 test. Working fine. use quickCheck queryBox_testing or verboseCheck queryBox_testing . trying to replace ++ with foldr lazy .
queryBox_testing :: Index -> ( ( Float , Float ) , ( Float , Float ) ) -> Property 
queryBox_testing x y = not ( null . queryBox x $ y ) ==> ( head . sort . queryBox x $ y ) * ( last . sort . queryBox x $ y ) == ( minimum . queryBox x $ y  ) * ( maximum . queryBox x $ y )   


queryBox (IndexEmpty size) _ = debugB ("queryBox IndexEmpty", size) []
queryBox (IndexLeaf size ids) _ = debugB ("queryBox IndexLeaf", size, ids) ids
queryBox (Index size ids down) box@((x1,y1),(x2,y2)) =
  -- TODO: If the viewport includes the entire block, just go grab everything. This isn't quite right yet
  if (coordSize x1 y1 x2 y2) > size
  then debugB ("all", size) $ ids ++ allIds down  {-- foldr (:) ( allIds down ) ids --} 
  else debugB ("searching", size, ids)  ids ++ recurse   {--foldr ( : ) recurse ids  --}  
  where
    nextSize = size / sizeIncrement
    xrange :: [Int]
    xrange = [(truncate $ x1/nextSize)..(truncate $ x2/nextSize)]
    yrange :: [Int]
    yrange = [(truncate $ y1/nextSize)..(truncate $ y2/nextSize)]
    allCoords :: [(Int, Int)]
    allCoords = crossProduct xrange yrange
    keys = map lebesgueDistance allCoords
    -- TODO: we need to only search the intersection of what could show up in this block
    recurse :: [Int]
    recurse = --debugB ("keys", x1, x2, nextSize, size, sizeIncrement, keys, box, xrange, yrange, allCoords)
        debugB ("searching keys", keys) $   
        foldl doit [] keys     --Todo try here to put foldr instead of foldl 
    doit :: [Int] -> Int -> [Int]
    doit results key = results ++ recurse where   --Todo here also foldr to concate 
      recurse = case IntMap.lookup key down of
        Nothing -> debugB "foundNothing" []
        Just nextInd -> debugB "foundNextInd" queryBox nextInd box

--Ok . Working fine .  use  quickCheck allIds_testing or verboseCheck allIds_testing. Also foldr would be great rather than foldl for laziness. 
allIds_testing :: IntMap.IntMap Index  -> Property
allIds_testing x  = not ( null . allIds $ x ) ==> ( head . sort . allIds $ x )   == ( minimum . allIds $ x )  

allIds :: IntMap.IntMap Index -> [Int]
allIds m = foldl getem [] (IntMap.elems m)   -- foldr ( flip getem ) [] ( IntMap.elems m )  


--Ok . use quickCheck getem_testing or verboseCheck getem_testing. 
getem_testing :: [ Int ] -> Index -> Property 
getem_testing x y = not ( null x ) ==> ( last . sort .  getem x $ y ) * ( head . sort . getem x $ y )  == ( maximum . getem x $ y ) * ( minimum . getem x $ y )  


getem :: [Int] -> Index -> [Int]
getem results (IndexEmpty _) = results
getem results (IndexLeaf _ ids) = results ++ ids
getem results (Index _ ids down) = results ++ ids ++ (allIds down)

--Ok . use quickCheck getemDown_testing or verboseCheck getemDown_testing . 
getemDown_testing :: Index -> Property
getemDown_testing x = not ( null . getemDown $ x ) ==> ( head . sort . getemDown $ x ) == (  minimum . getemDown $ x ) 


getemDown :: Index -> [Int]
getemDown (IndexEmpty _) = []
getemDown (IndexLeaf _ ids) = ids
getemDown (Index _ ids down) = ids ++ allIds down -- foldr (:) ( allIds down ) ids


--Ok no need for QuickCheck .Nicely typed by liftM2 
crossProduct :: [a] -> [a] -> [(a, a)]
crossProduct = liftM2 (,)

--great , This one passed all 100 cases almost instant . use quickCheck queryPoint_testing or verboseCheck queryPoint_testing
queryPoint_testing :: Index -> ( Float , Float ) -> Property
queryPoint_testing  ix ( x , y ) = not ( null . queryPoint ix $ ( x , y ) ) ==> ( head . sort . queryPoint ix $ ( x , y ) ) * ( last . sort . queryPoint ix $ ( x , y ) )  == ( minimum . queryPoint ix $ ( x , y ) ) * ( maximum . queryPoint ix $ ( x , y ) )   

queryPoint :: Index -> (Float, Float) -> [Int]
queryPoint (IndexEmpty size) _ = []
queryPoint (IndexLeaf size ids) _ = ids
queryPoint (Index size ids down) pt = ids ++ recurse  --foldr (:) recurse ids 
  where
    key = coordToInt size pt
    recurse = case IntMap.lookup key down of
      Nothing -> []
      Just nextInd -> queryPoint nextInd pt


-- insert :: Index -> Int -> Shape -> Index


insertShape shapeId ((x1, y1), (x2, y2)) ind = ind'
  where
    shapeSize = coordSize x1 y1 x2 y2
    ind' = insertIndex ind shapeId shapeSize (x1, y1)


--great . this one also passed all the 100 cases in fraction of seconds. use quickCheck coordSize_testing or verboseCheck coordSize_testing
coordSize_testing  x1 y1 x2 y2 = coordSize x1 y1 x2 y2 == coordSize x2 y2 x1 y1 

coordSize x1 y1 x2 y2 = max (abs (x1-x2)) (abs (y1-y2))


{-- Finding property to test this one is difficult but still apart from this testing , we can call getemDown :: Index -> [Int] function which converts the index to list of Int. use quickCheck --   insertIndex_testing or verboseCheck insertIndex_testing. Great passed both properties --}

insertIndex_testingA :: Index -> Int -> Float -> ( Float , Float ) -> Bool 
insertIndex_testingA ix  a b ( c , d ) = insertIndex ix a b ( c , d ) == insertIndex ix a b ( c , d ) 

insertIndex_testingB :: Index -> Int -> Float -> ( Float , Float ) -> Property
insertIndex_testingB ix a b ( c , d ) = not ( null . getemDown . insertIndex ix a b $ ( c , d ) ) ==> ( head . sort . getemDown . insertIndex ix a b $ ( c , d ) ) == ( minimum . getemDown . insertIndex ix a b $ ( c , d ) )

insertIndex :: Index -> Int -> Float -> (Float, Float) -> Index
insertIndex ind shapeId 0.0 coords = ind
insertIndex ind shapeId shapeSize coords =
  if isNaN shapeSize then debugB "foundNaN" ind else
  if key == -9223372036854775808 then ind else
      if --debugB ("insertIndex", shapeId, shapeSize, coords, currentSize, nextSize) $
        shapeSize <= currentSize && shapeSize > nextSize
      then case ind of
        IndexEmpty s -> IndexLeaf s [shapeId]
        IndexLeaf s xs -> IndexLeaf s $ shapeId:xs
        Index s xs down -> Index s (shapeId:xs) down
      else case ind of
        IndexEmpty s -> Index s [] $ recurse IntMap.empty
        IndexLeaf s xs -> Index s xs $ recurse IntMap.empty
        Index s xs down -> Index s xs $ recurse down
      where
        currentSize = indexSize ind
        nextSize = --debugB ("sizes", currentSize, sizeIncrement)
            currentSize / sizeIncrement

        key = coordToInt nextSize coords
        recurse :: IntMap.IntMap Index -> IntMap.IntMap Index
        recurse intMap = IntMap.alter (ap coords) key intMap

        ap :: (Float, Float) -> Maybe Index -> Maybe Index
        ap x (Just ind') = --debugB ("Existing Index: ", shapeId, size, currentSize) $
            Just $ insertIndex ind' shapeId shapeSize coords
        ap x Nothing = --debugB ("New Index: ", shapeId, size, currentSize) $
            Just $ insertIndex (IndexEmpty nextSize) shapeId shapeSize coords
        --insertIndex ind shapeId size coords



-- This one is simple enough to pass the test. :) passed all the 100 test cases but float comparision with == could be dangerous. Use abs . use quickCheck coordToInt_testing or verboseCheck coordToInt_testing
coordToInt_testing :: Float -> ( Float , Float ) -> Property
coordToInt_testing a ( x , y ) =  ( abs a ) >= 1e-6 ==> coordToInt a ( x , y ) == coordToInt a ( x , y )  

--Ok if size to prevent from not to be 0 . 
coordToInt :: Float -> (Float, Float) -> Int
coordToInt size (x, y) =
    if (size == 0) then debugB ("0 size") $
        lebesgueDistance (truncate $ x / size, truncate $ y / size)
    else lebesgueDistance (truncate $ x / size, truncate $ y / size)

{-- commented by mukesh

line :: Float -> Line (Vertex2 Float)
line i = Line (Vertex2 a a) (Vertex2 (a + i) (a + i))
  where a = i

--}

--this function is Ok. I tried to compare it mulplying by a number and dividing but this apporach cross the Int limit 2147483647 and making it negative. Passed all the 100 cases. Use quickCheck lebesgueDistance_testing or verboseCheck lebesgueDistance . Other testing thing could be write another version of lebesgueDistance and then compare output both functions .--}

lebesgueDistance_testing :: ( Int , Int ) -> Int -> Property 
lebesgueDistance_testing ( x , y ) k = ( k /=0 ) ==> lebesgueDistance ( x , y ) == lebesgueDistance ( x , y ) 
 
lebesgueDistance :: ( Int, Int ) -> Int
lebesgueDistance (x,y) =
    let ms = [(0x00FF00FF, 8), (0x0F0F0F0F, 4),
              (0x33333333, 2), (0x55555555, 1)]
        aaargh x (mask,shift) = (x B..|. (x `B.shiftL` shift)) B..&. mask
        x' = foldl aaargh x ms
        y' = foldl aaargh y ms
    in x' B..|. (y' `B.shiftL` 1)


{-- commented by mukesh

mkLine :: Float -> Float -> Float -> Float -> Line (Vertex2 Float)
mkLine x1 y1 x2 y2 = Line (Vertex2 x1 y1) (Vertex2 x2 y2)

--}


{--this part is commented by joel Shellman
-- runSaveIndex :: IO ()
-- runSaveIndex = do
--   args <- getArgs
--   let nShapes :: Int = case args of
--         "save" : n : _ -> read n
--   let ind = mkIndex (take nShapes randomLines)
--   encodeFile "index.save" ind
--   print "Saved index."


-- runPerfTest :: IO ()
-- runPerfTest = do
--   ind :: Index <- decodeFile "index.save"
--   print "Loaded index."
--   args <- getArgs
--   let nQueries :: Float = case args of
--         n : _ -> read n
--   let ns = sqrt nQueries
--   let upperLefts = crossProduct [0.0..ns] [0.0..ns]
--   let lowerLefts = crossProduct [1.0..ns] [1.0..ns]
--   let boxes = zip upperLefts lowerLefts
--   clockTime $ print $ show $ length $ foldl (\xs x -> (queryBox ind x) ++ xs ) [] boxes


-- runTests = do
--   let ind = mkIndex testShapes
--   test 1 $ [1,3,4] `equiv` queryBox ind ((0, 0), (2000, 2000))
--   test 2 $ [1, 4] `equiv` queryBox ind ((0, 0), (1, 1))
--   test 3 $ [2] `equiv` queryBox ind ((9000, 9000), (11000, 11000))


-- testShapes = [mkLine 0 0 1 1,
--               mkLine 10000 10000 10000.0001 10000,
--               mkLine 100 0 10200 0,
--               mkLine 0 0.00001 0 0.000011]

-- test :: Int -> Bool -> IO ()
-- test num b = do
--   print $ if b then "Passed Test " ++ show num else "Failed Test " ++ show num



-- mkIndex shapes = ind
--   where
--     lines = zip [1..] shapes
--     ind = foldl (\ind (count, v) -> (insert ind count v)) (qIndexEmpty 10e9) lines

-- 
-- randomLines :: [Line (Vertex2 Float)]
-- randomLines = map snd $ scanl rl ((mkStdGen 100000), line 0) randomCoords
--   where
--     --rl :: StdGen -> (Float, Float) -> Line (Vertex2 Float)
--     rl (rand, _) (x, y) = (rand'', Line (Vertex2 x y) (Vertex2 x2 y2))
--           where
--             (len, rand') = random rand
--             (p :: Float, rand'') = random rand'
--             factor = 10**(p*maxSizePower - (maxSizePower/2))
--             xOff = (x/mag * len * factor)
--             yOff = (y/mag * len * factor)
--             -- TODO: handle negative numbers
--             xOff' = if xOff < 1e-12 then xOff + 1e-3 else xOff
--             yOff' = if yOff < 1e-12 then yOff + 1e-3 else yOff
--             x2 = x - xOff'
--             y2 = y - yOff'
--             mag = sqrt((x*x)+(y*y))


-- randomCoords :: [(Float, Float)]
-- randomCoords =
--   map snd $ scanl randomPoint ((mkStdGen 1), (0,0)) [1..]


-- randomPoint :: RandomGen g => (g, (Float, Float)) -> Int -> (g, (Float, Float))
-- randomPoint (rand, _) _ = (rand'', (v1*maxLocation,v2*maxLocation))
--   where
--     (v1, rand') = random rand
--     (v2, rand'') = random rand'
--end of joel's comment
--}


debugB :: (Show a) => a -> b -> b
--debugB a b = trace (show a) b
debugB a b = b


-- |Subset test

subset          :: (Eq a) => [a] -> [a] -> Bool
a `subset` b    = and [ ma `elem` b | ma <- a ]

-- |Set equivalence test

equiv           :: (Eq a) => [a] -> [a] -> Bool
a `equiv` b     = a `subset` b && b `subset` a

