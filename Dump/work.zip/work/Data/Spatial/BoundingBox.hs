{-# LANGUAGE TemplateHaskell, FlexibleInstances, NoMonomorphismRestriction,
 StandaloneDeriving #-}

module Data.Spatial.BoundingBox (
  T(..), null, new, empty, universe, union, unions,
  overlap, inside, measure, project, center
  ) where

import Util.Num
import Util.Prelude (liftA4)
import qualified Data.Spatial.Vertex as Vertex
import Data.Ord (comparing, Ord(compare)) 
import Prelude hiding (zipWith, zipWith3, null)
import qualified Prelude as P

import Control.Applicative hiding (empty)
import qualified Data.Foldable as Fold
import Control.DeepSeq
import Snowfall.Binary
import Data.DeriveTH (derive, makeBinary, makeNFData)

data T v = Con { lower, upper :: v }
  deriving (Show)

-- instance Binary (T v a) where

instance (Vertex.C v a) => Eq (T (v a)) where
  box1@(Con l1 u1) == box2@(Con l2 u2)
    | null box1 && null box2 = True
    | otherwise = l1 == l2 && u1 == u2

deriving instance (Vertex.C v a) => Ord (T (v a)) 

lessOrEqual v1 v2 = Fold.all id $ liftA2 lessOrEqualInf v1 v2

null :: (Vertex.C v a)  => T (v a) -> Bool
null (Con l u) = not $ lessOrEqual l u

-- new :: (Vertex.C v, Ord a) => v a -> v a -> T v a
new v1 v2 = Con (Vertex.min v1 v2) (Vertex.max v1 v2)

empty = Con { lower = pure inf, upper = pure (- inf) }

universe = Con { lower = pure (- inf), upper = pure inf }

union box1@(Con l1 u1) box2@(Con l2 u2) =
  Con (Vertex.min l1 l2) (Vertex.max u1 u2)

unions = foldl union empty

overlap box1@(Con l1 u1) box2@(Con l2 u2) = Fold.all id $ liftA4 f l1 u1 l2 u2 
  where
  f l1 u1 l2 u2 = 
    abs ((l1 + u1) - (l2 + u2)) `lessOrEqualInf` (u1 - l1) + (u2 - l2)

Con l1 u1 `inside` Con l2 u2 = l2 `lessOrEqual` l1 && u1 `lessOrEqual` u2

-- {-# INLINE measure #-}
measure (Con l u) = Fold.product $ liftA2 (-) u l

-- enlargement :: Vertex.C v a => T (v a) -> T (v a) -> a
-- enlargement boxFrom box = measure (union boxFrom box) - measure boxFrom

-- project :: (v a -> a) -> T v a -> (a, a)
project f (Con l u) = (f l, f u)

center (Con l u) = liftA2 (\l u -> (l + u) / 2) l u 
-- contains (Con l u) v = l <= v && v <= u

-- diag (Con l u) = distance l u

-- delta (Con l1 u1) (Con l2 u2) = distance l1 l2 P.+ distance u1 u2

derive makeBinary ''T
derive makeNFData ''T

