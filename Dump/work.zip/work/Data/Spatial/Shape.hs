{-# LANGUAGE TypeFamilies, FlexibleContexts #-}

module Data.Spatial.Shape where

import qualified Data.Spatial.BoundingBox as Box
import qualified Data.Spatial.Vertex as Vertex

-- Is a shape = has bounding box
class C shape where
  type Vertex shape :: *
  boundingBox :: 
    (Vertex shape ~ v a, Vertex.C v a) => shape -> Box.T (Vertex shape)

type BoundingBox shape = Box.T (Vertex shape)

instance (C shape) => C [shape] where
  type Vertex [shape] = Vertex shape
  boundingBox = Box.unions . map boundingBox

commonBoundingBox :: (C shape, Vertex shape ~ v a, Vertex.C v a) => 
  [shape] -> BoundingBox shape
commonBoundingBox = Box.unions . map boundingBox

