{-# LANGUAGE TypeFamilies, FlexibleContexts, NoMonomorphismRestriction,
 Rank2Types, NamedFieldPuns, RecordWildCards, UndecidableInstances #-}

module Data.Spatial.Index where


import qualified Data.Spatial.Shape as Shape
import qualified Data.Spatial.BoundingBox as Box
--import qualified Data.Spatial.Vertex as Vertex
--no file named Vertex.hs in directory /Data/Spatial

--import qualified Data.Storage as Stor
-- no file name Storage.hs in Data folder
import Snowfall.Binary
import Util.Prelude
import qualified Data.Sequence as Seq
--import qualified Data.Sequence.Extra as Seq
import Data.List (partition)
import qualified Data.Foldable as Fold
import qualified Safe.Failure as Safe

type family Shape index :: *

type Query result index =
  (Shape index ~ s, Shape.Vertex s ~ v a,
  Shape.C s, Vertex.C v a, Binary s, Binary (v a)) =>
  Shape.BoundingBox s -> Stor.F index (result s, index)

-- not very useful now
type Insert index =
  (Shape index ~ s, Shape.Vertex s ~ v a,
  Shape.C s, Vertex.C v a, Binary s, Binary (v a)) =>
  [s] -> Stor.Update index

type InsideResult s = ([s], [s])

class (Stor.C index) => C index where
  -- Query shapes which intersect the box
  intersect :: Query [] index

  insertMany :: Insert index

-- Same as intersect, but separate shapes inside the box from other ones
inside :: C index => Query InsideResult index
inside = defaultInside intersect

defaultInside intersect box = mapFst (partition insideBox) <.> intersect box
  where insideBox s = Shape.boundingBox s `Box.inside` box

foldIntersect box is = do
  (shapes, is') <- Seq.unzip <$> Stor.mapM (intersect box) is
  return (concat . Fold.toList $ shapes, is')

foldInside = defaultInside foldIntersect

data StoreLastShape i = StoreLastShape {
  index :: i,
  lastShape :: Maybe (Shape i)
  }

instance Stor.C i => Stor.C (StoreLastShape i) where
  type Stor.Handle (StoreLastShape i) = Stor.Handle i
  run = Stor.applyRun index

instance (Binary i, Binary (Shape i)) => Binary (StoreLastShape i) where
  put StoreLastShape{..} = put index >> put lastShape
  get = liftA2 StoreLastShape get get

type instance Shape (StoreLastShape i) = Shape i
instance C i => C (StoreLastShape i) where
  intersect box self@StoreLastShape{..} = do
    (shapes, index') <- intersect box index
    return (shapes, self {index = index'})

  insertMany shapes self@StoreLastShape{..} = do
    index' <- insertMany shapes index
    return self { index = index', lastShape = Safe.last shapes }
