
-- This module is aimed to contain some simple common functions which
-- can be useful anywhere in the source

module Util.Prelude (
  module Util.Prelude,
  module Data.Eq.HT,
  module Control.Monad,
  module Control.Applicative,
  module Control.Arrow,
  module Control.Category,
  module Data.Maybe,
  module Data.List,
  module Debug.Trace,
  module Util.Debug,
  module Text.Printf,
  module Util.Num,
  module Data.Tuple.Extra,
  module Data.Foldable,
  module Data.Key,
  ) where

import Control.Applicative ((<$>), (<$), pure, (<*>), liftA, liftA2)
import Data.Eq.HT (equating)
import Data.Maybe
import Control.Monad ((>=>), (<=<), liftM, liftM2, liftM3, liftM4)
import Control.Arrow ((***), (&&&), Kleisli(..))
import Control.Category ((>>>), (<<<))
import Data.List (foldl')
import Debug.Trace
import Util.Debug
import Text.Printf (printf)
--import Util.Num
--import Data.Tuple.Extra
import Data.Foldable (foldMap)
import Data.Key ((!), mapWithKey)

-- Pair [Long Type Name] is shorter than ([Long Type Name], [Long Type Name])
-- and little easier to refactor
type Pair a = (a, a)

type Modify a = a -> a

infix 0 -->
x --> y  = (x, y)

lesserGreater :: Ord a => a -> a -> (a, a)
lesserGreater x y = if x <= y then (x, y) else (y, x)

minMax :: Ord a => (a, a) -> (a, a) -> (a, a)
minMax (l1, u1) (l2, u2) = (min l1 l2, max u1 u2)

-- foldMinMax :: RealFrac a => [(a, a)] -> (a, a)
-- foldMinMax = foldl' minMax (inf, -inf)

for :: Functor f => f a -> (a -> b) -> f b
for = flip fmap

-- Point-free version of >>
infixl 1 >>&
(>>&) :: Monad m => (a -> m b) -> (a -> m c) -> a -> m c
f >>& g = \x -> f x >> g x

-- Point-free version of <$>
infixl 4 <.>
(<.>) ::  Functor f => (b -> c) -> (a -> f b) -> a -> f c
f <.> g = fmap f . g

concatMapM ::  Monad m => (a -> m [b]) -> [a] -> m [b]
concatMapM f = liftM concat . mapM f

applyTo :: a -> (a -> b) -> b
applyTo x f = f x

-- Comparable to the `maybe' or `either' functions for their respective data
-- types.
bool :: a -> a -> Bool -> a
bool x _ False = x
bool _ y True  = y

liftA4 f a b c d = f <$> a <*> b <*> c <*> d
