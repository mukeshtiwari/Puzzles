-----------------------------------------------------------------------------
--
-- Module      :  Processor.ShapeTypes
-- Copyright   :  2010 Joel Shellman
-- License     :  AllRightsReserved
--
-- Maintainer  :  Joel Shellman
-- Stability   :
-- Portability :  Linux and Windows
--
-- |
--
-----------------------------------------------------------------------------

{-# LANGUAGE DeriveDataTypeable, TemplateHaskell, TypeFamilies,
  NamedFieldPuns, NoMonomorphismRestriction, TypeSynonymInstances #-}

module Processor.ShapeTypes (
  Vertex2(..), Color3(..), blackColor, GLNumber, Line(..),
  Shape, DrawShape, IdShape, drawShape, idShapeToShape,
  EventId(..), ShapeId, IdShapeList, creationTime,
  ViewSpace, OutlineStyle (..), g2d, d2g
  ) where

import Graphics.Rendering.OpenGL (Vertex2(..), Color3(..))
-- instances for OpenGL types
import Graphics.Rendering.OpenGL.Extra ()

import Data.Typeable
import Processor.EventId

import Util.Prelude
import Data.Spatial.Shape.Line
import qualified Data.Spatial.Shape as Shape

import Snowfall.Binary
import Control.DeepSeq
import Data.DeriveTH (derive, makeNFData)

type GLNumber = Float
type GLVertex2 = Vertex2 GLNumber

g2d :: GLNumber -> Double
g2d = fromRational . toRational -- realToFrac

d2g :: Double -> GLNumber
d2g = fromRational . toRational

blackColor = Color3 0 0 0 :: Color3 GLNumber

type ShapeId = Int -- TODO: maybe better type and maybe newtype

type Shape = Line2D GLNumber

nullLine = Line (Vertex2 0 0) (Vertex2 0 0) :: Shape

data OutlineStyle = Dotted | Filled | Dashed | DashDotDash
                  deriving (Eq, Show, Read, Typeable, Enum)

derive makeNFData ''OutlineStyle

instance Binary OutlineStyle where
  put = putWord8 . fromIntegral . fromEnum
  get = toEnum . fromIntegral <$> getWord8

type DrawShape = (Shape, Color3 GLNumber, OutlineStyle)

instance Shape.C DrawShape where
  type Shape.Vertex DrawShape = Shape.Vertex Shape
  boundingBox (shape, _, _) = Shape.boundingBox shape

type IdShape = (ShapeId, EventId, DrawShape)

instance Shape.C IdShape where
  type Shape.Vertex IdShape = Shape.Vertex Shape
  boundingBox (_, _, shape) = Shape.boundingBox shape

drawShape :: IdShape -> DrawShape
drawShape (_, _, ds) = ds

idShapeToShape :: IdShape -> Shape
idShapeToShape (_, _, (s, _, _)) = s

-- Use it for comparing / sorting shapes
creationTime :: IdShape -> Int
creationTime (_, EventId{uniqueCount}, _) = uniqueCount

type IdShapeList = [Maybe [IdShape]]

-- For now, we're just going to do a 1-D query on the x-axis
-- TODO LATER: handle general space queries
type ViewSpace = (GLNumber, GLNumber)
